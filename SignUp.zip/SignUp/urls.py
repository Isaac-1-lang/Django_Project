from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path('',views.home,name='index'),
    path('verify_code/',views.verify_code,name='signup'),
    # path('signup/',views.signup,name='signup'),
    # path('login/',views.login,name='login'),
    # path('logout/',views.logout,name='logout'),
]
