from django.shortcuts import render, redirect
from django.contrib.auth.models import User

def home(request):
    if request.method == "POST":
        name = request.POST.get("name")
        username = request.POST.get("username")
        phone = request.POST.get("phone_number")
        email = request.POST.get("email")  # Capture the email
        request.session["email"] = email  # Save email to session
        password = request.POST['password']
        confirmation = request.POST['confirm_password']

        # Check if password and confirmation match
        if password == confirmation:
            # Create a new user
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password
            )
            user.save()
            return redirect(f"/verify-email/?email={email}")  # Redirect to verify-email page with email

    return render(request, "aunthentication/index.html")


def verify_email(request):
    user_email = request.GET.get("email", "")  # Get email from query parameters
    return render(request, "aunthentication/confirmation_password.html", {"user_email": user_email})


def verify_code(request):
    # This view was initially planned to handle the verification code.
    # Since you no longer need it, we will leave it empty.
    return render(request, "aunthentication/confirmation_password.html")
