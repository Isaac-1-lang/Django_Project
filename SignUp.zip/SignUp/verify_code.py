import string
import random
# Getting email verification codes
uniques_chars = random.sample(string.ascii_letters + string.digits + string.punctuation + string.ascii_lowercase + string.hexdigits,8)
# Joining the chosen numbers
uniques_chars_str = ''.join(uniques_chars)
print(f"Your verification code is: {uniques_chars_str}")